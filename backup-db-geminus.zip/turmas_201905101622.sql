﻿INSERT INTO test.turmas (disciplinas_id,professores_id,semestres_id,nome,created_at,updated_at) VALUES 
(1,1,1,'A','2019-05-10 19:04:41.000','2019-05-10 19:04:41.000')
,(4,2,1,'B','2019-05-10 19:05:41.000','2019-05-10 19:05:41.000')
,(3,1,1,'t','2019-05-10 19:06:09.000','2019-05-10 19:06:09.000')
;