﻿INSERT INTO test.disciplinas (matrizes_id,nome,carga_horaria,ementa,periodo,created_at,updated_at) VALUES 
(8,'Lógica de Programação I',120,'Ementa Lógica',1,'2019-05-10 18:56:13.000','2019-05-10 18:56:13.000')
,(8,'Lógica de Programação II',120,'Lógica',2,'2019-05-10 18:56:39.000','2019-05-10 18:56:39.000')
,(6,'Farmacologia',60,NULL,4,'2019-05-10 18:57:21.000','2019-05-10 18:57:21.000')
,(7,'Lógica de Programação I',120,NULL,3,'2019-05-10 18:57:59.000','2019-05-10 18:57:59.000')
;