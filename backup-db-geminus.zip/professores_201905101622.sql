﻿INSERT INTO test.professores (nome,created_at,updated_at) VALUES 
('Ronaldo Del Fiaco',NULL,NULL)
,('Joilson Brito',NULL,NULL)
,('Noeli Pimentel',NULL,NULL)
,('Elke Dias',NULL,NULL)
;