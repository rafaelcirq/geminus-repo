﻿INSERT INTO test.pre_requisitos (disciplinas_id,pre_requisito_id,created_at,updated_at) VALUES 
(2,1,NULL,NULL)
,(3,3,NULL,NULL)
;