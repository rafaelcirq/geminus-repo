﻿INSERT INTO test.cursos (nome,created_at,updated_at) VALUES 
('Sistemas de Informação',NULL,NULL)
,('Engenharia Civil',NULL,NULL)
,('Farmácia',NULL,NULL)
,('Química Industrial',NULL,NULL)
,('Química Licenciatura',NULL,NULL)
,('Biologia',NULL,NULL)
,('Física',NULL,NULL)
;