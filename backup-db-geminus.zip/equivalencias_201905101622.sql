﻿INSERT INTO test.equivalencias (disciplinas_id_1,disciplinas_id_2,created_at,updated_at) VALUES 
(1,4,NULL,NULL)
;