﻿INSERT INTO test.horarios (dia,hora_inicio,hora_fim,created_at,updated_at) VALUES 
('Segunda-feira','16:40:00','18:20:00',NULL,NULL)
,('Segunda-feira','19:00:00','20:40:00',NULL,NULL)
,('Quarta-feira','14:50:00','16:30:00',NULL,NULL)
,('Quinta-feira','16:40:00','18:20:00',NULL,NULL)
,('Sexta-feira','19:00:00','20:40:00',NULL,NULL)
,('Sexta-feira','14:50:00','16:30:00',NULL,NULL)
,('Sexta-feira','16:40:00','18:20:00',NULL,NULL)
,('Sexta-feira','19:00:00','20:40:00',NULL,NULL)
;