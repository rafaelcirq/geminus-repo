﻿INSERT INTO test.migrations (migration,batch) VALUES 
('2014_10_12_000000_create_users_table',1)
,('2014_10_12_100000_create_password_resets_table',1)
,('2019_03_26_233200_create_cursos_table',1)
,('2019_03_26_233242_create_matrizes_table',1)
,('2019_04_04_210407_create_disciplinas_table',1)
,('2019_04_04_211145_create_pre_requisitos_table',1)
,('2019_04_04_211220_create_equivalencias_table',1)
,('2019_04_05_185321_create_professores_table',1)
,('2019_04_05_190134_create_semestres_table',1)
,('2019_04_05_191618_create_turmas_table',1)
;
INSERT INTO test.migrations (migration,batch) VALUES 
('2019_04_23_232101_create_horarios_table',1)
;