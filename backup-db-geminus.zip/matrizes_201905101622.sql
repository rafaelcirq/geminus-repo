﻿INSERT INTO test.matrizes (cursos_id,nome,ativa,created_at,updated_at) VALUES 
(8,'2010/1',1,NULL,NULL)
,(7,'2010/2',1,NULL,NULL)
,(6,'2011/1',1,NULL,NULL)
,(1,'2011/2',1,NULL,NULL)
,(4,'2015/2',1,NULL,NULL)
,(3,'2009/1',0,NULL,NULL)
,(2,'2002/1',0,NULL,NULL)
,(1,'2019/1',1,NULL,NULL)
;