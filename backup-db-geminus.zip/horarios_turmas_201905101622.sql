﻿INSERT INTO test.horarios_turmas (horarios_id,turmas_id) VALUES 
(1,11)
,(2,11)
,(3,11)
,(4,12)
,(5,12)
,(3,13)
,(4,14)
,(1,15)
,(10,16)
,(1,17)
;
INSERT INTO test.horarios_turmas (horarios_id,turmas_id) VALUES 
(1,18)
,(10,19)
,(6,20)
,(1,1)
,(3,3)
,(8,4)
;