﻿INSERT INTO test.usuario (CPF,email,password,`_token`,remember_token,created_at,updated_at) VALUES 
('12345678910','geminusueg@gmail.com','$2y$10$QSqrtAgyrI5LUrGKrxj4nuwRRG6wsrQngqIOt4AIaILwcL//o8bzK','ighDQ8ACl2UBbG6NkRJIS6uGUr70Xb6ad5EqXgtZ',NULL,'2019-02-22 13:49:44.000','2019-05-10 19:15:51.000')
,('12345678918','q@gmail.com','$2y$10$BWwsQHcghdNz7uBBtIveAOJrvYx5lV7ej1ycuyPtGr5iqXEpmP9TO','U81igFZH4wd0cANYjup8RaFmqt1gbnBuYDeWraQX',NULL,'2019-02-23 01:10:14.000','2019-03-26 23:21:45.000')
,('07728366041','ap@gmail.com','$2y$10$hSndeudMcWqPV/D8O/RLMOVsrQRGzdEUBvEFJ5wqzI8IPZTfkEUfa','bxPfbq8l0Tb8LL35ww4SnXuVCeb7WOsVTrWE2ne5',NULL,'2019-02-23 12:44:22.000','2019-03-15 20:27:13.000')
,('10283501431','resp@gmail.com','$2y$10$1i3wRAeejfkB.2IL5nWJ5u78o..yibthriy99JRj892byf3XxRJCe',NULL,NULL,'2019-02-27 13:04:05.000','2019-02-27 13:04:05.000')
,('56598842036','dyost@yahoo.com','$2y$10$f9y3U07GLboLLz30FuOeIO8f8cWyl2soFAyJ03ZCj8a.TtCa9HgVG',NULL,NULL,'2019-03-01 12:51:53.000','2019-03-01 12:51:53.000')
,('28303195085','alvera112@muller.com','$2y$10$UarEzYI4YuIqY7KODwoMdOrzhPxqsRK0Vrf2d73BLvPXxwXWgdWnK','lx7W3COkIJhkano4wn776CYfhMC4wPf1tlRFqaJm',NULL,'2019-03-01 12:51:53.000','2019-05-10 19:08:08.000')
,('70278382345','beier.aric@gmail.com','$2y$10$lWClJuBWL/we5kW24FhwfuE2r9Lh.GIYw4vJM.JdGXOcYuLghXZtS',NULL,NULL,'2019-03-01 12:51:53.000','2019-03-01 12:51:53.000')
,('91550947087','shea.monahan@runte.com','$2y$10$ZiJYHowdolIwroIh/jZlBOC4Nun8thzUJpjPaSxyS0Oc0MJ.RrNLO','LBGFZl6WAwQl7OStiITwk25GlCBVj1hKQztGS0rE',NULL,'2019-03-01 12:51:53.000','2019-04-25 18:45:12.000')
,('88670941946','wfarrell@herzog.info','$2y$10$PvC9ZDBZv2UvZp.EQl4udeFe3e7l7pvc09SGo0N99c89SGvlGfckK',NULL,NULL,'2019-03-01 12:51:53.000','2019-03-01 12:51:53.000')
,('62353397393','jaiden.koepp@gmail.com','$2y$10$tBjP2Lftlk7YJvKVhx2kjOb19U44ICkCllZbuUGCFQD1qDR5/I526',NULL,NULL,'2019-03-01 12:51:53.000','2019-03-01 12:51:53.000')
;
INSERT INTO test.usuario (CPF,email,password,`_token`,remember_token,created_at,updated_at) VALUES 
('58852805317','krista.wintheiser@skiles.biz','$2y$10$2mxI8M9wgKD2i7FQJUQ/7uPKFiudZVRMJiYLjc.JbP07IR23nU7Oe',NULL,NULL,'2019-03-01 12:51:53.000','2019-03-01 12:51:53.000')
,('40212268351','lwalsh@yahoo.com','$2y$10$Tkc0kFIbJxwgvEshasWeAOuU3PFEuzT8gWeedp9WfPdXURlbRdHDC',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('70330589610','mitchel41@gmail.com','$2y$10$xB66WjAPq605gFLkeZGFfem45CIuLExwWkCW/IlqeC1lBSB8flIMK',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('48429078097','christiansen.pattie@sawayn.com','$2y$10$U0Trp2A8epWqdACodOlMkuRhsdbV2dytdcW2p4NFcsmsjPqXVbkT6',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('48956998489','xander17@borer.com','$2y$10$oGtx0qBmONmYCosS9HuTA.Jm..AfoQgEwzRi8Es47Jmi0c9K0.O.O',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('47757510698','maynard.mohr@yahoo.com','$2y$10$Kb5BVGuZogTwIp/Iqe/bAel72k9UuNToWCqVwFpXZhuuhAWhlhytK',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('34324448608','king.noemie@yahoo.com','$2y$10$5wpUSoQHtMSUqrlSOwMSXunW3YVEmnACyP2lwpLMsVS9YVhtGDir.',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('77575870101','claudia89@hotmail.com','$2y$10$i0pkgP9.M14qX2F6bOlleOXydlmHhZEM1QiBZwJ8SBm5CoUevs4Aa',NULL,NULL,'2019-03-01 12:51:54.000','2019-03-01 12:51:54.000')
,('12345678914','emailmail@gmail.com','$2y$10$5T9mDXY616Lpl.gnvL/lluGW1YijYbxG0lDtFv/auKtmF.lxL73qu',NULL,NULL,'2019-03-16 15:06:01.000','2019-03-16 15:06:01.000')
,('15789654615','silverbolt@gmail.com','$2y$10$uQ/CHNQCCkWrjY2vS8qWZ.KIHR9nvEc32Qtph0NKE.rzdCN9UYfMe','J3BGkCT0nmpC70eMkA0f3KYZVa9pKNaqZCsslflg',NULL,'2019-03-16 15:09:28.000','2019-03-17 13:06:14.000')
;
INSERT INTO test.usuario (CPF,email,password,`_token`,remember_token,created_at,updated_at) VALUES 
('36589541201','mail@gmail.com','$2y$10$lMKw7kqM5NW8b/UqTgLWqe.UiRkvVGWz40slqLOcHM3Pe1RfwIclW',NULL,NULL,'2019-03-16 15:28:18.000','2019-03-16 15:28:18.000')
,('45876541212','bb@gmail.com','$2y$10$kzzmILYfAIDS58zFUKsW9eZWse17zaHB2u.0LsrSRleA2SZozLyaC',NULL,NULL,'2019-03-16 15:29:46.000','2019-03-16 15:29:46.000')
,('58964785412','mailoi@gmail.com','$2y$10$q3uvp4eAg/PEce9aOC0BuObVsvUaZBGUD0oxZu7Ny3rJ95.xv/LZS',NULL,NULL,'2019-03-17 12:55:45.000','2019-03-17 12:55:45.000')
,('12345678911','emailooo@gmail.com','$2y$10$61lZzvP9Sdhqw9vgQl.1xuTAPfps6r5FOGoVc5JoyV71HP6nTkqH6','U81igFZH4wd0cANYjup8RaFmqt1gbnBuYDeWraQX',NULL,'2019-03-25 13:02:26.000','2019-03-26 23:20:50.000')
,('30299051013','emailbemgrande@gmail.com','$2y$10$oW0zBNMzQJo0ci1KAhvK.eXvSn9N01IGBtBaToe3Wr97XDhsez2e2','hYG8ZegKpHSZOAMp4FUxCCo7J6lEpZkUF24rxuTc',NULL,'2019-05-03 18:38:33.000','2019-05-03 18:38:58.000')
,('56598379059','troqueiemail@email.com','$2y$10$4GYvtK4abubKqyw3gE/djO.rfjt73Y3xMcgSrBXMa2o6PaUBe196.','lx7W3COkIJhkano4wn776CYfhMC4wPf1tlRFqaJm',NULL,'2019-05-10 19:08:37.000','2019-05-10 19:09:04.000')
;