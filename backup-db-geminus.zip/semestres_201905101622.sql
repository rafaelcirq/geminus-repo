﻿INSERT INTO test.semestres (semestre,created_at,updated_at) VALUES 
('2018/1',NULL,NULL)
,('2018/2',NULL,NULL)
,('2019/1',NULL,NULL)
,('2019/2',NULL,NULL)
;